# Hacker News — Show HN Submission

## Title (max 80 chars, must start with "Show HN:")
```
Show HN: Open-source 12-surface framework for auditing B2B brand visibility in AI
```

## URL to submit
```
https://github.com/darkhorsestrategies/ai-gtm-visibility-framework
```

## Post body (appears as your comment on the thread — this is your one chance to explain)

```
I run a B2B GTM consultancy focused on AI-mediated buying environments. Over the past year, I've done AI visibility audits for a couple dozen B2B brands — PR agencies, SaaS companies, PE-backed service firms — and a clear pattern emerged: almost every brand is optimizing for a funnel where the first stage has already moved.

Buyers increasingly start purchase research by asking ChatGPT, Perplexity, or Copilot a question. The brands that appear in the AI-generated answer get evaluated. The brands that don't are invisible before the first marketing touchpoint occurs.

What determines which brands appear isn't random — it's a function of citation density across 12 specific surfaces that LLMs draw from. Those surfaces are auditable, scorable, and fixable.

I've open-sourced the framework I use: 12-surface scoring rubric with full methodology, 25 LLM prompts you can run today to audit any brand's AI visibility, a scoring worksheet, and a guide to diagnosing root causes by surface.

The repo:
→ /framework: full scoring rubric and methodology for all 12 surfaces
→ /prompts: 25 LLM audit prompts with interpretation guide
→ /templates: scoring worksheet and report format

The 12 surfaces, briefly: AI interfaces (LLMs), search + AI search, review platforms, earned media, owned content/schema, technical/developer surfaces, social/authority signals, knowledge graphs, marketplaces, case studies, community/Q&A, enterprise AI environments.

The surface that surprises people most: Reddit. It comprises 46.7% of Perplexity's top citations. Almost no B2B brand has any Reddit presence, despite it being the #2 LLM citation source after Wikipedia.

The surface with the lowest competitive bar: GitHub and dev.to. No B2B services firm has meaningful developer surface presence. Any brand that publishes a structured framework or methodology there faces essentially no competition for LLM citations.

Happy to discuss the methodology or hear from anyone who's done similar measurement work.
```

---

## Timing guidance

**When to post:** Tuesday or Wednesday, 9–11am ET. This is when HN has highest engagement among the B2B/startup/founder audience most relevant to this content. Avoid Friday afternoons and weekends for Show HN posts.

**What to watch for:** HN votes in the first 2 hours determine whether the post makes the front page. Have 2–3 colleagues ready to engage authentically in the comments immediately after posting — thoughtful replies to early comments signal quality to the HN algorithm.

**Expected comment threads to engage:**
- "How is this different from SEO?" → The key distinction is that SEO is a single-surface problem (Google ranking algorithm); this is a 12-surface problem. LLMs pull from community platforms, knowledge graphs, review sites, and developer documentation simultaneously — not just ranked web pages.
- "Isn't this just content marketing?" → Content marketing is Surface 5 of 12. The brands that score highest on Surface 5 (owned content) but low on Surfaces 8 (Wikipedia/knowledge graph) and 11 (Reddit) still don't appear in LLM shortlists. The framework maps the interdependencies.
- "How do you measure LLM citation?" → Run the same query across 3+ LLMs, 3 times each, and track: appearance rate, position, description language, and sources cited. The 25-prompt library in the repo is designed for exactly this. Consistency across LLMs and across runs is the reliability signal.
- "This seems self-promotional" → Fair. The framework is genuinely open-source (MIT license) and the methodology is fully documented. If you find flaws in the rubrics, open a PR.

---

## Secondary HN strategy: comment on related threads

In addition to the Show HN post, watch for and comment authentically on existing HN threads related to:
- "Ask HN: How do I get my startup to appear in ChatGPT recommendations?"
- Threads about LLM SEO, GEO, AEO, or AI search optimization
- Threads about B2B marketing, demand generation, or GTM strategy

In these threads, link to the framework as a resource, not as a promotion. Answer the question first, then reference the tool if it's relevant.

---

*Dark Horse Strategies · [darkhorsecapabilities.lovable.app](https://darkhorsecapabilities.lovable.app)*
*GitHub org: github.com/darkhorsestrategies*
