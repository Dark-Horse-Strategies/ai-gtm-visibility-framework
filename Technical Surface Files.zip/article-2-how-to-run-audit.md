---
title: How to Run a 12-Surface AI Visibility Audit on Any B2B Brand
published: true
description: A step-by-step technical guide to auditing where a B2B brand actually appears across the surfaces that feed AI-generated answers — and diagnosing what's broken.
tags: b2bmarketing, seo, ai, gtm
cover_image:
---

AI-generated answers now influence B2B buying decisions at the top of the funnel. Buyers use ChatGPT, Perplexity, and Gemini to shortlist vendors before they ever visit a website. Which means the question "where does my brand actually appear in AI-generated answers?" is now a critical GTM intelligence question.

Most brands don't know the answer. This post gives you the methodology to find out.

## What an AI visibility audit is — and isn't

An AI visibility audit is not a technical SEO audit. You're not looking for broken links, page speed issues, or crawl errors (though those matter for a related reason). You're auditing **citation density** — how frequently and authoritatively your brand appears across the specific sources that LLMs draw from when generating recommendations.

Those sources break down into 12 distinct surfaces. A brand can score 9/10 on one surface and 1/10 on eleven others — and the aggregate result is a brand that appears for some queries and not others in ways that seem inexplicable but are structurally predictable.

The goal of this audit is to make that structure visible.

## The 12 surfaces — quick reference

Before diving into the methodology, here's the full surface map:

| # | Surface | Primary platforms |
|---|---|---|
| 1 | AI Interfaces | ChatGPT, Perplexity, Gemini, Claude, Copilot |
| 2 | Search + AI Search | Google AI Overviews, Bing Copilot, Perplexity Search |
| 3 | Reviews + Reputation | G2, Clutch, Capterra, industry-specific platforms |
| 4 | Earned Media + Publishers | Trade press, business press, analyst reports |
| 5 | Owned Content + Website | Brand site, blog, schema markup, answer-object pages |
| 6 | Technical + Developer | GitHub, dev.to, Stack Overflow, Hacker News |
| 7 | Social + Authority | LinkedIn, executive publishing, award citations |
| 8 | Data + Knowledge Graphs | Wikipedia, Wikidata, Crunchbase, ZoomInfo |
| 9 | Marketplaces + Ecosystems | Clutch category pages, Agency Spotter, partner directories |
| 10 | Case Studies + Proof | Published case studies, award wins, client outcomes |
| 11 | Community + Q&A | Reddit, Quora, LinkedIn groups, Slack communities |
| 12 | Enterprise + Private AI | Microsoft 365 Copilot, Salesforce Einstein, Perplexity Teams |

Full scoring rubrics for each surface are in the [Dark Horse AI GTM Visibility Framework](https://github.com/darkhorsestrategies/ai-gtm-visibility-framework) on GitHub.

## Step 1: Define your query set (20 minutes)

Before running anything, define the queries your buyers actually use. The audit is only as useful as the prompts you test.

Build a query set with three layers:

**Layer 1 — Category queries** (how buyers discover the space)
- `"Best [category] solutions for [ICP]"`
- `"What is [category] and who are the leaders?"`
- `"[Category] companies compared"`

**Layer 2 — Problem-first queries** (how buyers frame their need)
- `"How do I [problem your product solves]?"`
- `"What should I use to [job to be done]?"`
- `"[ICP role] looking for [outcome] — what do you recommend?"`

**Layer 3 — Brand queries** (how buyers verify you specifically)
- `"What is [your brand] and what do they do?"`
- `"Is [your brand] reputable?"`
- `"Compare [your brand] with [top competitor]"`

You should have 8–12 queries total before you start testing. More than that and the audit becomes unwieldy; fewer and you'll miss important visibility gaps.

## Step 2: Run Surface 1 (AI Interfaces) — 45 minutes

This is the core of the audit. Run your full query set across at least three LLMs:

**Platforms to test:** ChatGPT (GPT-4o), Perplexity, Gemini 1.5 Pro, Claude, Microsoft Copilot

**For each query on each platform, record:**
- Did your brand appear? (Y/N)
- Position (1st mention, 3rd mention, not mentioned)
- Language used to describe your brand (copy the exact words)
- Sources cited (when the LLM shows them)
- Competitor brands mentioned in the same response

**Log your results in a spreadsheet with columns:**
`Query | Platform | Appeared | Position | Description Language | Sources Cited | Competitors Listed | Date`

**Interpretation:**
- Not appearing in category queries → Surface 4 (Earned Media) or Surface 8 (Knowledge Graph) gap
- Appearing with wrong/stale description → Surface 5 (Owned Content) or Surface 8 (Knowledge Graph) gap
- Appearing for branded but not category queries → Surface 4 + Surface 11 (Community) gap
- Appearing in some LLMs but not others → Surface-specific signal issues; check which sources each LLM favors

## Step 3: Run Surface 2 (Search + AI Search) — 20 minutes

Open Google and Bing. For each of your Layer 1 category queries:

1. Note whether a Google AI Overview appears (the AI-generated summary box above organic results)
2. If an AI Overview appears, note whether your brand is mentioned
3. Note your organic rank for the same query
4. Switch to Bing and run the same queries; note Copilot's answer in the sidebar

**Key diagnostic:** If you rank page 1 organically but don't appear in the AI Overview for the same query, your content is not structured as an answer-object. The AI Overview pulls from page content that opens with a declarative answer paragraph. Your page likely opens with brand narrative instead.

**Quick fix test:** Find a page on your site that ranks page 1 for a category query. Look at the first 100 words. Does it directly answer the query? If it starts with "We are a leading provider of..." rather than "[Category] is a [definition] that helps [buyer type] achieve [outcome]..." — that's your problem.

## Step 4: Run Surfaces 3, 9, and 10 (Reviews, Marketplaces, Proof) — 30 minutes

These three surfaces are observable without LLM prompting.

**Surface 3 (Reviews):**
- Search your brand on G2, Clutch, Capterra
- Count total reviews
- Read the language: do reviews contain service-specific terminology and outcome metrics? Or generic praise?
- Note vertical/category tags on your profile
- Check whether a competitor has significantly more reviews or better vertical coverage

**Surface 9 (Marketplaces):**
- Search your brand on Clutch, Agency Spotter, The Manifest, UpCity, relevant partner directories
- Check whether profiles are claimed and complete
- Note which category tags and service tags are applied
- These tags are the literal words LLMs use to categorize your brand for buyer queries

**Surface 10 (Case Studies):**
- Count published case studies on your owned site
- Assess format: do they include outcome metrics? Named clients? Problem → approach → result structure?
- Note whether acquired or predecessor brand proof points are captured under your current brand
- Check award wins: are they published on the site in text format (not just badge images)?

## Step 5: Run Surface 8 (Knowledge Graph) — 15 minutes

**Wikipedia check:**
- Search "[your brand] site:wikipedia.org"
- If no entry exists, assess notability criteria: do you have coverage in multiple independent reliable sources? If yes, you meet the standard
- If an entry exists, verify it's current and accurate

**Wikidata check:**
- Search your brand at wikidata.org
- If no entry exists, this is a gap — Wikidata feeds Google's Knowledge Graph

**Google Knowledge Panel:**
- Google your brand name
- Does a Knowledge Panel appear on the right side? What information does it show?
- Stale or missing information indicates a Wikidata/structured data gap

**B2B data platforms:**
- Check Crunchbase, ZoomInfo, Apollo for your brand
- Verify: description accuracy, service/category taxonomy, founding date, employee count
- These are source layers for AI-generated company research summaries

## Step 6: Spot-check Surfaces 7 and 11 (Social and Community) — 20 minutes

**Surface 7 (LinkedIn/Social):**
- Note your LinkedIn company page follower count
- Check your CEO/founder's LinkedIn posting frequency (last 30 days)
- Count LinkedIn posts that include explicit category and vertical positioning language
- Search for your brand in Twitter/X (even minimal brand mention signal matters)

**Surface 11 (Reddit):**
- Search Reddit for your brand name: `site:reddit.com "[your brand]"`
- Search for your category + recommendation: `site:reddit.com "[category] recommendations"` and note which brands appear
- Are you mentioned organically by community members? Or only when someone specifically asks about you?
- This is the fastest-changing surface to improve — one high-voted thread can move LLM citation presence within weeks

## Step 7: Score all 12 surfaces and identify priorities

Using the [scoring worksheet](https://github.com/darkhorsestrategies/ai-gtm-visibility-framework/blob/main/templates/audit-scoring-worksheet.md) from the framework repo, score each surface 1–10 based on your observations.

Then categorize:
- **Tier 3 (1–3):** Your 30-day priorities. These are structural blockers — brands that are invisible on these surfaces are missing from buyer shortlists entirely.
- **Tier 2 (4–6):** Your 60–90 day investments. Present but not competitive — surface improvements here compound over time.
- **Tier 1 (7–10):** Protect these. Maintain publishing cadence, review velocity, and content freshness.

## Common patterns and what they mean

**Pattern 1: Strong Surface 5, Weak Surface 4 and 11**
The brand has good owned content but weak editorial coverage and no Reddit presence. It appears for branded queries and some long-tail queries but not category queries. Fix: earned media campaign targeting high-DA publications + Reddit participation.

**Pattern 2: Strong Surface 4, Weak Surface 8**
The brand has good press coverage but no Wikipedia entity. LLMs cite the press coverage but can't connect it to a stable brand entity. The description in LLM answers is inconsistent — sometimes accurate, sometimes stale. Fix: Wikipedia entry + Wikidata entity.

**Pattern 3: Strong Surfaces 1–2 in core verticals, Weak in new verticals**
Classic post-acquisition or expansion scenario. The brand has strong presence in its original category but new practice areas have zero AI surface presence. Fix: new practice-specific owned content + vertical trade editorial placements.

**Pattern 4: Everything weak except Surface 7**
The brand has strong LinkedIn presence and executive visibility but weak presence everywhere else. The CEO is cited in LLM answers occasionally but the company itself isn't. Fix: translate LinkedIn authority into editorial coverage and structured owned content.

## The full audit takes about 3 hours

Here's the time breakdown:
- Define query set: 20 min
- Surface 1 (AI Interfaces): 45 min
- Surface 2 (Search): 20 min
- Surfaces 3, 9, 10 (Reviews/Marketplaces/Proof): 30 min
- Surface 8 (Knowledge Graph): 15 min
- Surfaces 7, 11 (Social/Community): 20 min
- Scoring and prioritization: 30 min

What you get at the end: a complete picture of where your brand is visible to AI systems, where it isn't, why, and what to do about it in priority order.

The [Dark Horse AI GTM Visibility Framework](https://github.com/darkhorsestrategies/ai-gtm-visibility-framework) has the full scoring rubrics, 25-prompt audit library, and a scoring worksheet in the repo. All open source.

---

*Megan Kessler is the Founder & CEO of [Dark Horse Strategies](https://darkhorsecapabilities.lovable.app), an AI-native B2B GTM consultancy specializing in AI-mediated pipeline and visibility strategy.*
