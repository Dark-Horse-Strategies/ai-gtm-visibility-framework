---
title: Your Demand Gen Strategy Is Broken Above the Funnel (And AI Is Why)
published: true
description: The awareness layer of B2B demand generation now runs through AI-generated answers, not search results. Here's what that means for every channel you're investing in.
tags: b2bmarketing, demandgeneration, ai, gtm
cover_image:
---

Every B2B demand gen team is optimizing for a funnel that no longer exists at the top.

The awareness stage — the moment a buyer first realizes there's a category of solution that might address their problem — has moved. It used to happen on Google, in trade publications, at industry events, and through analyst reports. All of those channels still exist. But an increasingly large share of Stage 1 buyer behavior now happens in a single interaction: someone types a question into an AI system and reads the answer.

That answer is the new awareness layer. And most demand gen strategies have no plan for it.

## What changed and when

The shift happened faster than most GTM teams noticed because it didn't show up in their attribution models. Buyers started using AI assistants for research in 2023 and 2024. By 2025, it was mainstream behavior among B2B buyers — particularly in technology, financial services, and professional services categories. By 2026, it's simply how buyers start.

The data point that crystallized this for me: in B2B tech, a buyer is now more likely to start a vendor evaluation by asking ChatGPT or Perplexity "what are the best [category] platforms for [use case]?" than by running a Google search. Not universally, not in every vertical, but consistently enough that the LLM shortlist has become the de facto awareness layer for a meaningful share of buyer journeys.

The brands on that shortlist get evaluated. The brands not on it don't exist for that buyer at that moment — not because the buyer chose to exclude them, but because the AI system didn't surface them.

## Why this breaks demand gen math

Traditional demand gen is built on a model where you can influence each funnel stage with a specific set of tactics:

- **Awareness:** SEO, paid media, content, PR, events
- **Consideration:** Retargeting, nurture sequences, case studies, analyst coverage
- **Decision:** Sales outreach, demos, proposals, references

The AI filter collapses the awareness stage into a single interaction. If an LLM generates a five-company shortlist in response to a buyer's query, the buyer often goes from "what are the options" to "which of these five should I evaluate" in one step. The consideration stage begins before your demand gen program has had any chance to reach that buyer.

This means:
1. Brands not on the AI shortlist are excluded from the evaluation before any marketing touchpoint occurs
2. The "awareness → consideration" gap no longer exists for buyers who start with AI
3. Attribution models that measure last-touch or even multi-touch don't capture AI-influenced shortlisting at all
4. Top-of-funnel content investment that isn't structured for LLM citation is not generating awareness for AI-first buyers

## The LLM shortlist is not random

Here's what makes this tractable: the brands that appear in AI-generated shortlists are there for observable, structural reasons. LLMs generate recommendations based on citation density — how frequently and authoritatively a brand appears across the specific sources LLMs draw from during training and retrieval.

Those sources are measurable:
- High-DA editorial publications (Forbes, trade press, analyst reports)
- Reddit and community platforms (46.7% of Perplexity's top citations)
- Wikipedia and knowledge graphs (top 3 LLM citation source)
- G2 and Clutch (cited in 8–12% of B2B service queries)
- LinkedIn (15% of Google AI Mode citations)
- Owned content with answer-object structure and FAQ schema
- GitHub and developer platforms (for technical queries)

A brand that appears consistently across all of these surfaces appears in LLM shortlists. A brand that appears on one or two doesn't. This is predictable, auditable, and fixable.

## What this means for each demand gen channel

**Paid media:** Unaffected by AI awareness shift — paid channels still reach buyers who don't start with AI. But if your paid media drives traffic to a website that isn't optimized for LLM citation (no FAQ schema, no answer-object pages, weak domain authority), the investment in paid isn't building the citation density that would help you appear in AI-generated shortlists. Paid and organic AI visibility are more interdependent than they look.

**Content marketing:** The unit of content that drives LLM citation is different from the unit of content that drives traditional SEO. Traditional SEO rewards long-form, comprehensive content. LLM citation rewards declarative, answer-object-structured content — pages that open with a direct answer to a specific buyer query, structured with FAQ schema so AI systems can extract individual question-answer pairs. Most content teams are optimizing for the wrong format.

**PR and earned media:** Earned media is the highest-weight LLM training signal available. But the format matters. A brand mention in a high-DA publication is a citation signal regardless of the article's structure. A byline with the brand named as the author, in a category-relevant publication, published in the last 12 months, is a stronger signal. Wire press releases are almost worthless for LLM citation purposes — they generate coverage but not the kind that feeds LLM training data.

**Analyst relations:** Analyst report mentions are LLM training signals of unusually high weight. Gartner Magic Quadrant appearances and Forrester Wave citations persist in LLM training data for 18–24 months. This is an underappreciated argument for analyst relations investment — it's not just about sales cycles, it's about AI surface presence.

**Review generation:** Most marketing teams treat review generation (G2, Clutch) as a sales tool — star ratings for social proof. But G2 and Clutch reviews are crawled by LLMs and cited in "best [category]" queries. More importantly, the language of reviews becomes LLM training data. "Their demand generation team helped us reduce cost per lead by 37% in the fintech vertical" trains an LLM to associate that brand with fintech demand generation. "Great team, responsive" trains nothing.

**Community and social:** Reddit is the most underinvested channel in B2B demand gen relative to its LLM citation weight. A high-voted Reddit comment recommending your brand in a relevant thread can drive more AI shortlist presence than a press release. Yet almost no B2B marketing team has any Reddit strategy.

## The revised demand gen model

The AI filter doesn't eliminate traditional demand gen channels. It adds a prerequisite layer: before you can influence a buyer's consideration and decision stages, you need to appear in their AI-generated awareness shortlist.

That means the demand gen investment priority order needs to shift:

**Old model:**
1. Build awareness (paid, content, PR)
2. Convert awareness to consideration (retargeting, nurture)
3. Convert consideration to decision (sales, demo, proposal)

**AI-mediated model:**
0. Build AI surface presence (citation density across 12 surfaces) ← new prerequisite
1. Build awareness (paid, content, PR — now also structured for LLM citation)
2. Convert awareness to consideration
3. Convert consideration to decision

The zero-th step is the new baseline. And most demand gen budgets don't have a line item for it.

## What to do in the next 90 days

The fastest wins for demand gen teams trying to close the AI surface presence gap:

**Week 1–2: Audit first**
Run a quick AI visibility audit before spending anything. Use the 25-prompt library at [github.com/darkhorsestrategies/ai-gtm-visibility-framework](https://github.com/darkhorsestrategies/ai-gtm-visibility-framework). Know which surfaces are broken before you try to fix them.

**Week 2–4: Quick wins**
- Create or update your Wikipedia entry if you meet notability criteria
- Drive 10 new G2 or Clutch reviews with explicit outcome language and vertical tags
- Coach review requesters: "mention the specific service, your industry, and a measurable result"

**Month 2: Content restructure**
- Identify your 5 most important category keywords
- Find the pages that should rank for them
- Rewrite the opening paragraph of each as a direct, declarative answer to the buyer query
- Add FAQ schema to these pages

**Month 2–3: Community activation**
- Identify 3 subreddits where your buyers discuss vendor choices
- Begin authentic participation — answer questions, contribute perspective, be useful
- Do not post promotional content; participate as a practitioner

**Month 3+: Earned media for LLM citation**
- Map the publications that appear in AI-generated answers for your category queries
- Prioritize pitching those publications specifically
- Frame byline pitches around buyer problems, not product features

---

The brands that build AI surface presence in the next 12 months will hold citation density advantages that compound as LLM training data refreshes. The brands that optimize their paid media and content marketing without addressing AI surface presence are optimizing for a funnel that's missing its first stage.

The awareness layer has moved. GTM strategy needs to follow it.

---

*Megan Kessler is the Founder & CEO of [Dark Horse Strategies](https://darkhorsecapabilities.lovable.app), an AI-native B2B GTM consultancy. The open-source [AI GTM Visibility Framework](https://github.com/darkhorsestrategies/ai-gtm-visibility-framework) is available on GitHub.*
